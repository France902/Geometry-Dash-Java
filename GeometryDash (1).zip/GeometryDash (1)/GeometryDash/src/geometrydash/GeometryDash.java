
    package geometrydash;

    import java.awt.Graphics;
    import java.awt.Graphics2D;
    import java.awt.Image;
    import java.awt.Rectangle;
    import java.awt.event.*;
    import java.awt.geom.AffineTransform;
    import java.awt.image.BufferedImage;
    import java.util.LinkedList;
    import java.util.Random;
    import javax.swing.*;
    import java.net.URL;
    import java.util.ArrayList;
    import java.util.Arrays;

    

    public class GeometryDash extends JFrame {

        JFrame frame = new JFrame();        
        
        static int W = 100, H = 100, WS = 1000, HS = 1000, playerX = -100, playerY = 860;
        int[] cont = {0};
        float[] contJump = {0};
        int gravity = 1;
        float speed;
        GamePanel gamePanel;
        boolean isJumping = false;
        boolean isGrounded = false;
        boolean suspendPhysics = false;
        boolean cuboCentrato = false;
        
        Timer gameLoop;
        
        static ArrayList<Livello> livelli = new ArrayList<>();

        public GeometryDash() {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            frame.setTitle("Scatto Geometrico");

            frame.setLayout(new java.awt.BorderLayout());
            
            java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
            int screenW = (int) screenSize.getWidth();
            int screenH = (int) screenSize.getHeight();

            Img cubo = new Img("/resources/images/Cubo.png", "cubo", W, H, playerX, playerY);
            Img pavimento = new Img("/resources/images/pavimento.png", "pavimento", screenW, 1000, 0, 950);
            Img titolo = new Img("/resources/images/Title1.png", "titolo", 1200, 200, screenW / 2, screenH / 2);
            Img sfondo = new Img("/resources/images/sfondo.png", "sfondo", screenW, screenH, 0, 0);

            gamePanel = new GamePanel(this, cubo, pavimento, livelli.get(0).getSpini(), livelli.get(0).getPiattaforme(), livelli.get(0).getPortaliGravitaGiallo(), 
                    livelli.get(0).getPortaliGravitaBlu(), livelli.get(0).getPortaliNavicella(), livelli.get(0).getPortaliCubo(), livelli.get(0).getFine(), titolo, sfondo);
            frame.add(gamePanel);

            frame.setFocusable(true);
            frame.requestFocusInWindow();
            
            float[] contTimers = {0};  

            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (!gamePanel.isGameStarted) return;
                    
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_ESCAPE:
                            System.exit(0);
                        case KeyEvent.VK_SPACE:
                            switch(cubo.getTipo()) {
                                case "cubo":
                                    if(isGrounded && !isJumping) {
                                        isJumping = true;
                                        saltaPlayer(cubo);
                                    }
                                    break;
                                case "navicella":
                                    muoviNavicella(cubo, contTimers[0]);
                                    contTimers[0] += 0.7f;
                                    if(contTimers[0] > 12) contTimers[0] = 12;
                                    break;
                            }   
                            break;
                        case KeyEvent.VK_1:
                            if(isGrounded && !isJumping) {
                                trasformaNavicella(cubo);
                                cubo.setRotation(0);
                            }
                            break;
                        default:
                            break;
                    }
                }
                
                
                
                @Override
                public void keyReleased(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_SPACE) {

                        if (cubo.getTipo().equals("navicella")) {
                            contTimers[0] = 0;
                            cont[0] = 0;
                            ripristinaFisica(); 
                            
                        }
                    }
                }
            });
            
            javax.swing.Timer mouseTimer = new javax.swing.Timer(16, e -> {
                        switch(cubo.getTipo()) {
                            case "cubo":
                                if(isGrounded && !isJumping) {
                                    isJumping = true;
                                    saltaPlayer(cubo);
                                }
                                    break;
                                case "navicella":
                                    muoviNavicella(cubo, contTimers[0]);
                                    contTimers[0] += 0.7f;
                                    if(contTimers[0] > 12) contTimers[0] = 12;
                                    break;
                            } 
            });

            frame.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getButton() == MouseEvent.BUTTON1) {
                        mouseTimer.start();
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    if (e.getButton() == MouseEvent.BUTTON1) {
                        mouseTimer.stop();
                        
                        if (cubo.getTipo().equals("navicella")) {
                            contTimers[0] = 0;
                            cont[0] = 0;
                            ripristinaFisica(); 
                            
                        }
                    }
                }
            });


            frame.setVisible(true);
            
            
            
            gameLoop = new Timer(16, e -> {
                
                if(gamePanel.isGameStarted){
                    if(!suspendPhysics) {
                        if(!checkCollisionGravity(cubo, pavimento, livelli.get(0).getPiattaforme()) && !isJumping) {
                            updatePhysics(cubo, pavimento, cont[0]);
                            cont[0]+= 2;
                        }
                        else {
                            if(cubo.getRotation() != 90) {
                            cont[0] = 0;
                            }
                            if(!isJumping) {
                                raddrizzaCubo(cubo);
                            }
                        }

                    }
                    if(!cuboCentrato) moveCubo(cubo);
                    else updateMovement(livelli.get(0).getSpini(), livelli.get(0).getPiattaforme(), livelli.get(0).getPortaliGravitaGiallo(), livelli.get(0).getPortaliGravitaBlu(), 
                            livelli.get(0).getPortaliNavicella(), livelli.get(0).getPortaliCubo(), livelli.get(0).getFine(), cubo);                 
                    gamePanel.repaint(); 
                }
            });
            gameLoop.start();
        }
        
        public void moveCubo(Img cubo) {
            int currentX = cubo.getX();
            currentX += 11;
            
            if(currentX > 500) {
                cuboCentrato = true;
                currentX = 500;
            }
            
            cubo.setX(currentX);
        }
    
        public void caricaLivelloSpecifico(int n) {
            // Svuota le liste attuali
            livelli.clear();
            livelli.add(new Livello(n));

            // Aggiorna i riferimenti nel gamePanel
            gamePanel.setBackground(livelli.get(0).getLvColor());
            gamePanel.spini = livelli.get(0).getSpini();
            gamePanel.piattaforme = livelli.get(0).getPiattaforme();
            gamePanel.portaliGravitaGiallo = livelli.get(0).getPortaliGravitaGiallo();
            gamePanel.portaliGravitaBlu = livelli.get(0).getPortaliGravitaBlu();
            gamePanel.portaliNavicella = livelli.get(0).getPortaliNavicella();
            gamePanel.portaliCubo = livelli.get(0).getPortaliCubo();
            gamePanel.fine = livelli.get(0).getFine();
            gamePanel.isGameWin = false;
            gameLoop.start();
            
        }
        
        public void trasformaNavicella(Img cubo) {
            cubo.setTipo("navicella");
            try {
                URL resource = getClass().getResource("/resources/images/razzo.png");
                BufferedImage nuovaImg = javax.imageio.ImageIO.read(resource);

                cubo.setBufferedImage(nuovaImg); 

                gamePanel.repaint();

            } catch (Exception e) {
                System.out.println("Errore nel caricamento dell'immagine navicella: " + e.getMessage());
            }
        }
        
        public void trasformaCubo(Img cubo) {
            cubo.setTipo("cubo");
            try {
                URL resource = getClass().getResource("/resources/images/cubo.png");
                BufferedImage nuovaImg = javax.imageio.ImageIO.read(resource);

                cubo.setBufferedImage(nuovaImg); 

                gamePanel.repaint();

            } catch (Exception e) {
                System.out.println("Errore nel caricamento dell'immagine navicella: " + e.getMessage());
            }
        }
        
        public void muoviNavicella(Img navicella, float cont) {
            sospendiFisica();
            int currentY = navicella.getY();
            float rotation = navicella.getRotation();
            rotation -= 1.5f;
            if(rotation <= -30) rotation = -30;     
            navicella.setRotation(rotation);
            currentY -= (3 + cont);
            navicella.setY(currentY);
        }
        
        public void sospendiFisica() {
            suspendPhysics = true;
        }
        
        public void ripristinaFisica() {
            suspendPhysics = false;
        }
        
       
        
        
        public void updatePhysics(Img cubo, Img pavimento, int cont) {
                int currentY = cubo.getY();
                int currentX = cubo.getX();
                float rotation = cubo.getRotation();
                
                if(cubo.getTipo().equals("cubo")) {
                    rotation += 2.30f;
                    if(rotation >= 360) rotation -= 360;
                    cubo.setRotation(rotation);
                    speed = 0.7f*cont;
                } else {
                    rotation += 1.50f;
                    if(rotation >= 30) rotation = 30;
                    cubo.setRotation(rotation);
                    speed = 0.4f*cont;
                }  

                if(speed > 30) speed = 30;

                currentY += speed * gravity;
                
                cubo.setY(currentY);

            
        }
        
        public void raddrizzaCubo(Img cubo) {
            int i, index = 0, verso;
            int[] closerAngle = {90};
            float[] rotation = {cubo.getRotation()};
            float[] differences = {Math.abs(0 - rotation[0]), Math.abs(90 - rotation[0]), Math.abs(180 - rotation[0]), Math.abs(270 - rotation[0]), Math.abs(360 - rotation[0])};
            float min = differences[0];

            for(i=1;i<4;i++) {
                if(min > differences[i]) {
                    index = i;
                    min = differences[i];
                }
            }

            switch(index) {
                case 0:
                    closerAngle[0] = 0;
                    break;
                case 1:
                    closerAngle[0] = 90;
                    break;
                case 2:
                    closerAngle[0] = 180;
                    break;
                case 3:
                    closerAngle[0] = 270;
                    break;
                case 4:
                    closerAngle[0] = 360;
                    break;
                default:
                    closerAngle[0] = 0;
                    break;
            }

            if(closerAngle[0] - rotation[0] >= 0) verso = 1;
            else verso = -1;
            if(Math.abs(closerAngle[0] - rotation[0]) > 6) rotation[0] += (6*verso);
            else rotation[0] = closerAngle[0];

            cubo.setRotation(rotation[0]);
        }
        
        public boolean checkCollisionGravity(Img oggetto1, Img oggetto2, ArrayList<Img> piattaforme) {
            Rectangle rect1 = new Rectangle(oggetto1.getX(), oggetto1.getY(), oggetto1.getW(), oggetto1.getH());
            Rectangle rect2 = new Rectangle(oggetto2.getX(), oggetto2.getY(), oggetto2.getW(), oggetto2.getH());
            
            if(gravity == 1) {
                if (rect1.intersects(rect2) && (oggetto1.getY() <= oggetto2.getY())) {
                    isGrounded = true;
                    return true;
                } 
                for(Img piattaforma : piattaforme) {
                    rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());
                    if (rect1.intersects(rect2) && (oggetto1.getY() <= piattaforma.getY())) {
                       isGrounded = true;
                        return true;
                    } 
                }
                
                rect1.grow(30, 30);
            
                if (rect1.intersects(rect2) && (oggetto1.getY() <= oggetto2.getY())) {
                    isGrounded = true;
                    return false;
                } 

                for(Img piattaforma : piattaforme) {
                    rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());

                    if (rect1.intersects(rect2) && (oggetto1.getY() <= piattaforma.getY())) {
                        isGrounded = true;
                        return false;
                    } 
                }
            } else {
                if (rect1.intersects(rect2) && (oggetto1.getY() > oggetto2.getY())) {
                    isGrounded = true;
                    return true;
                } 
                for(Img piattaforma : piattaforme) {
                    rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());
                    if (rect1.intersects(rect2) && (oggetto1.getY() > piattaforma.getY())) {
                       isGrounded = true;
                        return true;
                    } 
                }
                
                rect1.grow(20, 20);
            
                if (rect1.intersects(rect2) && (oggetto1.getY() > oggetto2.getY())) {
                    isGrounded = true;
                    return false;
                } 

                for(Img piattaforma : piattaforme) {
                    rect2 = new Rectangle(piattaforma.getX(), piattaforma.getY(), piattaforma.getW(), piattaforma.getH());

                    if (rect1.intersects(rect2) && (oggetto1.getY() > piattaforma.getY())) {
                        isGrounded = true;
                        return false;
                    } 
                }
            }
 
            
            isGrounded = false;
            return false;
        }
        
        public boolean controllaTocco(Img oggetto1, Img oggetto2) {
            int offset; 
            Rectangle rect1;
            if(oggetto1.getTipo() == "spina") {
                offset = 12;
                rect1 = new Rectangle(
                    (int) Math.round(oggetto1.getX() + (offset / 2.0)),
                    (int) Math.round(oggetto1.getY() + (offset / 2.0)),
                    oggetto1.getW() - offset,
                    oggetto1.getH() - offset
                );  
            } else rect1 = new Rectangle(oggetto1.getX(), oggetto1.getY(), oggetto1.getW(), oggetto1.getH());
                 
            Rectangle rect2 = new Rectangle(oggetto2.getX(), oggetto2.getY(), oggetto2.getW(), oggetto2.getH());

            if (rect1.intersects(rect2)) {
                return true;
            } 
            return false;
        }
        
        public void saltaPlayer(Img cubo) {
            
            
            Timer jumpTimer = new Timer(16, e -> {
                if(isJumping) {
                    int currentY = cubo.getY();
                    float rotation = cubo.getRotation();
                    
                    rotation += 5;
                    cubo.setRotation(rotation);
                    currentY -= (23 - contJump[0]) * gravity;

                    cubo.setY(currentY);

                    contJump[0] += 1f;
                    
                    if(contJump[0] >= 10) {
                        isJumping = false;
                        cont[0] = (int) contJump[0] * -1;
                        contJump[0] = 0;
                        ((Timer)e.getSource()).stop();
                    }
                }
                
            });
            
            jumpTimer.start();
        }
        
        public void updateMovement(ArrayList<Img> spini, ArrayList<Img> piattaforme, ArrayList<Img> portaliGravitaGiallo, ArrayList<Img> portaliGravitaBlu, 
                ArrayList<Img> portaliNavicella, ArrayList<Img> portaliCubo, ArrayList<Img> fine, Img cubo) {
            Timer ripristinaTimer = new Timer(300, e -> {
                gamePanel.cuboDeleted = false;
                ricominciaLivello();
            });
            int spostamento = 11;
                if(gamePanel.cuboDeleted) return;
                for(Img spina : spini) {
                    if(!controllaTocco(spina, cubo)) {
                        int currentX = spina.getX();
                        
                        currentX -= spostamento;
                        spina.setX(currentX);
                    } else {
                        gamePanel.deleteCubo();
                        ripristinaTimer.setRepeats(false);
                        ripristinaTimer.start();
                        
                    }
                }
                
                for(Img piattaforma : piattaforme) {
                    if(!controllaTocco(piattaforma, cubo)) {
                        int currentX = piattaforma.getX();

                        currentX -= spostamento;
                        piattaforma.setX(currentX);
                    } else {
                        if(gravity == 1) {
                            if(Math.abs(piattaforma.getY() - cubo.getY()) <= 70) {
                            gamePanel.deleteCubo();
                            } else {

                                int currentX = piattaforma.getX();

                                currentX -= spostamento;
                                piattaforma.setX(currentX);
                            }
                        } else {
                            if(Math.abs(piattaforma.getY() - cubo.getY()) > 70) {
                            gamePanel.deleteCubo();
                            } else {

                                int currentX = piattaforma.getX();

                                currentX -= spostamento;
                                piattaforma.setX(currentX);
                            }
                        }
                        
                        
                    }
                }
                
                for(Img portale : portaliNavicella) {
                    int currentX = portale.getX();

                    currentX -= spostamento;
                    portale.setX(currentX);

                    if(controllaTocco(portale, cubo)) {
                        if(portale.getIsValid()) {
                            portale.setIsValid(false);
                             cubo.setRotation(0);
                            trasformaNavicella(cubo);
                        }
                    }  
                }
                
                for(Img portale : portaliCubo) {
                    int currentX = portale.getX();

                    currentX -= spostamento;
                    portale.setX(currentX);

                    if(controllaTocco(portale, cubo)) {
                        if(portale.getIsValid()) {
                            portale.setIsValid(false);
                            cubo.setRotation(0);
                            trasformaCubo(cubo);
                        }
                    }  
                }
                
                for(Img portale : portaliGravitaGiallo) {
                    int currentX = portale.getX();

                    currentX -= spostamento;
                    portale.setX(currentX);

                    if(controllaTocco(portale, cubo)) {
                        if(portale.getIsValid()) {
                            portale.setIsValid(false);
                            cambiaGravità("giallo");
                        }
                    }  
                }
                
                for(Img portale : portaliGravitaBlu) {
                    int currentX = portale.getX();

                    currentX -= spostamento;
                    portale.setX(currentX);

                    if(controllaTocco(portale, cubo)) {
                        if(portale.getIsValid()) {
                            portale.setIsValid(false);
                            cambiaGravità("blu");
                        }
                    }  
                }  
                
                 for(Img f : fine) {
                    int currentX = f.getX();

                    currentX -= spostamento;
                    f.setX(currentX);

                    if(controllaTocco(f, cubo)) {
                        if(f.getIsValid()) {
                            f.setIsValid(false);
                            fineLivello(cubo);
                        }
                    }  
                }
                
            
        }
        
        public void fineLivello(Img cubo) {
            gameLoop.stop();
            animazioneCubo(cubo);
        }
        
        public void animazioneCubo(Img cubo) {
            int[] cont = {0};
            Timer animazione = new Timer(16, e -> {
                float rotation = cubo.getRotation();
                int currentY = cubo.getY();
                currentY -= 4;
                rotation += 5f;
                
                cont[0]++;
                cubo.setRotation(rotation);
                cubo.setY(currentY);
                
                gamePanel.repaint(); 
                
                if(cont[0] == 100) {
                    cubo.setX(-100);
                    cubo.setRotation(0);
                    cubo.setY(860);
                    cuboCentrato = false;
                    gamePanel.creaMenuVittoria();
                    gamePanel.isGameWin = true;
                    ((Timer)e.getSource()).stop();
                }
            });
            
            animazione.start();
        }
        
        public void ricominciaLivello() {
            livelli.clear();
            creaLivelli();
            
            gamePanel.spini = livelli.get(0).getSpini();
            gamePanel.piattaforme = livelli.get(0).getPiattaforme();
            gamePanel.portaliGravitaGiallo = livelli.get(0).getPortaliGravitaGiallo();
            gamePanel.portaliGravitaBlu = livelli.get(0).getPortaliGravitaBlu();
            gamePanel.portaliNavicella = livelli.get(0).getPortaliNavicella();
            gamePanel.portaliCubo = livelli.get(0).getPortaliCubo();
            
            gamePanel.removeAll();
            gamePanel.revalidate(); // Utile se hai rimosso componenti reali
            gamePanel.repaint();
        }
        
        public void cambiaGravità(String tipo) {
            if("giallo".equals(tipo)) gravity = -1;
            else gravity = 1;
            cont[0] = -10;
            speed = 0;
        }
        

        public static void main(String[] args) {
            creaLivelli();
            new GeometryDash();
        }
        
        public static void creaLivelli() {
            livelli.add(new Livello(1));
        }

    }
