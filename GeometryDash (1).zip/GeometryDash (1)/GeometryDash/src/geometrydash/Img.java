package geometrydash;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 * Rappresenta un elemento grafico del gioco (Cubo, Spina, Piattaforma).
 */
public class Img { // Rimosso "extends JFrame", non serve!
    
    private BufferedImage bufferedImage;
    private int W, H, X, Y;
    private float rotation = 0;
    private String tipo;
    private boolean isDeleted = false;
    private boolean isValid = true;
    
    public Img(String url, String tipo, int W, int H, int X, int Y) {
        this.W = W;
        this.H = H;
        this.X = X;
        this.Y = Y;
        this.tipo = tipo;
        
        //if(tipo == "fine") return;
        
        try {
            URL imgUrl = getClass().getResource(url);
            if (imgUrl == null) {
                System.err.println("Errore: Immagine non trovata al percorso: " + url);
                return;
            }
            
            // Carichiamo l'immagine originale
            BufferedImage originale = ImageIO.read(imgUrl);
            
            // Scaliamo l'immagine direttamente in una BufferedImage delle dimensioni corrette
            this.bufferedImage = resize(originale, W, H);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private BufferedImage resize(BufferedImage img, int newW, int newH) {
        Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
        BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = dimg.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();

        return dimg;
    }

        
    // Getter per la BufferedImage
    public BufferedImage getBufferedImage() {
        return bufferedImage;
    }

    // Altri Getter e Setter
    public String getTipo() { return tipo; } 
    public int getX() { return X; } 
    public int getY() { return Y; } 
    public int getW() { return W; } 
    public int getH() { return H; } 
    public float getRotation() { return rotation; }
    public boolean getIsValid() { return isValid; }
    
    public void setY(int Y) { this.Y = Y; } 
    public void setX(int X) { this.X = X; } 
    public void setTipo(String tipo) {this.tipo = tipo;}
    public void setRotation(float rotation) { this.rotation = rotation; }
    public void setBufferedImage(BufferedImage img) {this.bufferedImage = img;} 
    public void setIsValid(boolean isValid) { this.isValid = isValid; } 
}